from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
	return render_template("Home.html")

@app.route('/photo')
def photo():
        return render_template("Photo.html")

@app.route('/song')
def song():
        return render_template("Song.html")


if __name__ == '__main__':
	app.run(debug=True)
